#ifndef ROUTER_H
#define ROUTER_H
#include <queue>
#include "base_classes.h"
#include "geodb.h"

class Router : public RouterBase
{
public:
	Router(const GeoDatabaseBase& geo_db) : geodb(geo_db) {}
	virtual ~Router() {}
	virtual std::vector<GeoPoint> route(const GeoPoint& pt1,
		const GeoPoint& pt2) const;

	void print(vector<GeoPoint> path)
	{
		for (GeoPoint gp : path)
			cerr << gp.to_string() << endl;
	}
private:
	const GeoDatabaseBase& geodb;
	struct Cell {
		GeoPoint point;
		double f_score;
		Cell(const GeoPoint& p, double f) : point(p), f_score(f) {}
	};
	struct lowestFScore {
		bool operator()(const Cell& pt1, const Cell& pt2) const {
			return pt1.f_score > pt2.f_score;
		}
	};
	bool findInQueue(const priority_queue<Cell, vector<Cell>, lowestFScore>& pq, GeoPoint geo) const;
	vector<GeoPoint> reconstructPath(HashMap<GeoPoint>& cameFrom, GeoPoint cur) const;

};

#endif
